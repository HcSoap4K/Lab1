// 数组的大小
const int N = 1e5 + 10;

// 链式前向星存图
struct Edge {
    int next, to, dis;
    bool friend operator<(const Edge& a, const Edge& b) {
        return a.dis > b.dis;
    }
} edge[N];
int num_edge;
int head[N];
void add_edge(int from, int to, int dis) {
    edge[num_edge].next = head[from];
    edge[num_edge].to = to;
    edge[num_edge].dis = dis;
    head[from] = num_edge++;
}

// 基本参数
int n, m;     // n: 点的个数, m: 边的个数
int ans;      // 最小生成树的权值
int cnt;      // 点集中点的数量
bool vis[N];  // 标记点的数组

// Prim算法
bool prim() {
    priority_queue<Edge> q;  // 堆优化
    // 以节点1作为起点如点集
    vis[1] = true;
    ++cnt;
    // 遍历节点1相邻的边加入堆
    for (int i = head[1]; i != -1; i = edge[i].next) {
        int v = edge[i].to;
        if (vis[v])
            continue;
        q.push(edge[i]);
    }
    while (!q.empty()) {  // 若堆中没有边，则结束循环
        int point = 0;
        Edge u = q.top();
        point = u.to;
        if (vis[point]) {  // 若该点已经在点集中，则将该边从堆中删除
            q.pop();
            continue;
        }
        ++cnt;              // 点集中点数加1
        vis[point] = true;  // 标记该点
        ans += u.dis;       // 累加树权
        if (cnt == n)       // 若点集中点数已经达到n则结束循环
            break;
        for (int i = head[point]; i != -1;
             i = edge[i].next) {  // 找该节点相邻的新边
            int v = edge[i].to;
            if (vis[v])
                continue;
            q.push(edge[i]);
        }
    }
    if (cnt == n)  // 若点集中点的数量为n个，说明最小生成树构建完成
        return true;
    else  // 否则构建失败
        return false;
}

// 初始化
void init() {
    num_edge = ans = cnt = 0;
    memset(head, -1, sizeof head);
    memset(vis, false, sizeof vis);
}

// 主函数
int main() {
    // 初始化
    init();
    // 输入部分
    scanf("%d%d", &n, &m);          // 输入点数和边数
    for (int i = 1; i <= m; i++) {  // 建图
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        add_edge(u, v, w);
        add_edge(v, u, w);
    }
    // 调用prim函数，构造最小生成树
    if (!prim())  // 构造失败输出-1
        printf("-1\n");
    else  // 构造成功输出树权
        printf("%d\n", ans);
}
———————————————— 版权声明：本文为CSDN博主「岛上的黄鸡」的原创文章，遵循CC 4.0 BY -
    SA版权协议，转载请附上原文出处链接及本声明。 原文链接：https
    :  // blog.csdn.net/Hc_Soap/article/details/114554482
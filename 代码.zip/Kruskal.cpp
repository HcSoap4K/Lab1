// 基本参数
int n, m;  // n是边的数量，m是点的数量
int ans;   // 树权

// 并查集维护边集
int fa[N];
int find(int x) {
    return fa[x] == x ? x : fa[x] = find(fa[x]);
}
void merge(int x, int y) {
    int f1 = find(x);
    int f2 = find(y);
    fa[f1] = f2;
}

// 边的结构体
struct Edge {
    int x, y, z;
    bool friend operator<(const Edge& a, const Edge& b) {
        return a.z < b.z;  //边权较小的排在前面
    }
} e[N];

// Kruskal算法
bool kruskal() {
    for (int i = 1; i <= n; i++)
        fa[i] = i;
    sort(e + 1, e + 1 + m);
    int cnt = 0;
    ans = 0;
    for (int i = 1; i <= m; i++) {
        int fx = find(e[i].x), fy = find(e[i].y);  //查询x，y分别属于哪个集合
        if (fx == fy)
            continue;   //如果已经在同一个集合就继续扫下一条边
        merge(fx, fy);  //将x，y所在的两个集合合并
        cnt++;          //已经找到的边数加1
        ans += e[i].z;  //答案累加这条边的权值
    }
    return cnt == n - 1;
    //如果找的边数恰好有n-1条，则存在最小生成树，否则不存在
}